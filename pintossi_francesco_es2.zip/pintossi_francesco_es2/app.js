function calcolaOrdine() {
  const pizzaPrices = {
    "Margherita": 6.00,
    "Diavola": 7.00,
    "Quattro Formaggi": 8.00,
    "Vegetariana": 7.50
  };

  
  const pizzaTypeElement = document.getElementById("pizzaType");
  const pizzaType = pizzaTypeElement.value;

  
  const pizzaPrice = pizzaPrices[pizzaType];


  const ingredientiExtraElements = document.querySelectorAll('input[type="checkbox"]:checked');
  let ingredientiExtra = [];
  ingredientiExtraElements.forEach(checkbox => {
    ingredientiExtra.push(checkbox.value);
  });

  const prezzoIngredientiExtra = ingredientiExtra.length * 1.00;

  const quantita = parseInt(document.getElementById("quantity").value);

  const totale = (pizzaPrice + prezzoIngredientiExtra) * quantita;

  document.getElementById("ordineTipoPizza").textContent = pizzaType;
  document.getElementById("ordineIngredientiExtra").textContent = ingredientiExtra.length > 0 ? ingredientiExtra.join(', ') : 'Nessuno';
  document.getElementById("ordineQuantita").textContent = quantita;
  document.getElementById("ordineTotale").textContent = totale.toFixed(2);
  document.getElementById("ordineRiepilogo").classList.remove("hidden");
}
